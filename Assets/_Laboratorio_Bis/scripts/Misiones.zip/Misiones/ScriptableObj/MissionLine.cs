using UnityEngine;

namespace Quests
{
    /// <summary>
    /// L�nea de misi�n: una secuencia lineal de fases (0..N-1).
    /// - lineId es CLAVE para guardado/carga.
    /// - La fase 0 suele ser Intro (preview/brief).
    /// </summary>
    [CreateAssetMenu(fileName = "Line_", menuName = "Quests/Mission Line")]
    public class MissionLine : ScriptableObject
    {
        [Header("Identidad de la l�nea")]
        [Tooltip("ID estable de la l�nea. Ej: line/npc_profesor_intro")]
        public string lineId;

        [Tooltip("Nombre visible de la misi�n para UI/listados.")]
        public string displayName;

        [Header("Fases en orden")]
        public MissionPhase[] phases;
    }
}
